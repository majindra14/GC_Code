*** I am interested in compiling all of this data to make a table that summarizes average titer and standard deviation. See Table S6 in attached Supplementary File. 

* From March of 2021 forward, samples were analyzed for C10:1. You can delete these rows if it makes your data processing easier (ie if it is easier for each sample to have the same number of rows).

* You will notice C17cp in some samples. You can ignore or delete.

* The attached script that makes the bar plots is the most current. Note that as of now it is coded to expect C10:1 in each sample. The bottom block after the graph output is what arranges the titer and standard error of the mean and outputs it to Excel in the way we like to report it.

* The complete list of all variants in file BTE_full_mutant_list. The number of unique data points in these spreadsheets shoudl match the number of entries in this file.
